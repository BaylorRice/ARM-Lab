This is just a placeholder for the 4_memory directory.
